# Bolera Unity · proyecto base

Proyecto normal de Unity con la escena de la bolera **sin scripts propios adjuntos**. Está pensado para que el alumnado añada los tres scripts durante la clase.

## Abrir

1. Descarga y extrae el ZIP completo.
2. En Unity Hub, elige **Add / Añadir → Add project from disk** y selecciona esta carpeta (la que contiene `Assets`, `Packages` y `ProjectSettings`).
3. Ábrela con Unity **6000.6.0f1** y espera a que termine la importación.
4. Abre `Assets/Scenes/Bolera.unity`.

La escena conserva pista, materiales, cámara, bola, seis bolos y la jerarquía visual. Los bolos están sin Rigidbody ni Collider para que se añadan durante la práctica. El objeto `CentroBolos` también se crea en clase siguiendo la guía. La bola conserva su Sphere Collider y Rigidbody.

## Añadir scripts

Crea `Assets/Scripts` y copia dentro `BoloBolera.cs`, `LanzamientoBolera.cs` y `PanelBolera.cs` desde el paquete de scripts separado. Después sigue la guía docente incluida en `Documentacion/`.

La carpeta `Library`, `Temp`, `Obj`, `Logs` y `UserSettings` no se incluyen; Unity las genera localmente.
