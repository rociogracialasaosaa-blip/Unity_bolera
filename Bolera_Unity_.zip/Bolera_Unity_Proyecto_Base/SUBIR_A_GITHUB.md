# Subir la bolera a GitHub

1. Crea un repositorio nuevo para este proyecto o abre el repositorio de clase.
2. Sube la carpeta del proyecto conservando `Assets`, `Packages` y `ProjectSettings`.
3. Incluye `.gitignore` y evita subir `Library`, `Temp`, `Obj`, `Logs` y `UserSettings`.
4. Sube los scripts por separado en el repositorio o usa la carpeta `Assets/Scripts` del paquete de scripts.
5. Descarga el ZIP del repositorio y abre su carpeta raíz con Unity Hub; no abras solo el `.unity` suelto.
