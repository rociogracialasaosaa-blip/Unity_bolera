using UnityEngine; // Importa las herramientas de Unity para físicas, colisiones y vectores.

[RequireComponent(typeof(Rigidbody))] // Añade un Rigidbody automáticamente si falta en el objeto raíz.
public class BoloBolera : MonoBehaviour // Controla la física y el recuento de un bolo.
{
    [SerializeField, Range(10f, 85f)] private float anguloDerribado = 50f; // Inclinación mínima para contar el bolo como derribado.
    [SerializeField, Min(0.01f)] private float caidaVertical = 0.4f; // Descenso mínimo para contar el bolo como derribado.
    [Tooltip("Giro extra al recibir un impacto. Sube este valor si los bolos apenas se inclinan.")] // Ayuda visible en el Inspector.
    [SerializeField, Min(0f)] private float ayudaDeGiro = 6f; // Impulso de giro extra aplicado al impacto.

    private Rigidbody cuerpo; // Guarda el Rigidbody del bolo.
    private Vector3 inicio; // Guarda la posición inicial del bolo.
    private Quaternion rotacionInicial; // Guarda la rotación inicial del bolo.
    private bool fisicaActivada; // Indica si la bola ya ha golpeado y se permite mover este bolo.

    public bool RecibioGolpe { get; private set; } // Indica al controlador que este bolo ha recibido un impacto.
    public bool Derribado => cuerpo != null && // Comprueba que exista el Rigidbody antes de medir la inclinación.
        (Vector3.Angle(rotacionInicial * Vector3.up, cuerpo.rotation * Vector3.up) >= anguloDerribado || // Cuenta el giro suficiente...
         cuerpo.position.y < inicio.y - caidaVertical); // ...o una bajada suficiente.

    public bool EnReposo => cuerpo == null || cuerpo.IsSleeping() || // Se considera en reposo si el cuerpo está dormido...
        (cuerpo.linearVelocity.sqrMagnitude < 0.04f && cuerpo.angularVelocity.sqrMagnitude < 0.09f); // ...o casi no se mueve.

    public void GuardarInicio() // El controlador llama a este método al preparar la escena.
    {
        cuerpo = GetComponent<Rigidbody>(); // Busca el Rigidbody del mismo objeto raíz.
        inicio = cuerpo.position; // Guarda la posición original.
        rotacionInicial = cuerpo.rotation; // Guarda la rotación original.
        cuerpo.isKinematic = true; // Mantiene el bolo inmóvil mientras espera el lanzamiento.
        cuerpo.useGravity = false; // Evita que la gravedad lo haga caer antes del impacto.
        fisicaActivada = false; // Bloquea el movimiento hasta que la bola golpee la formación.

        if (GetComponentInChildren<Collider>() == null) // Comprueba si el bolo tiene algún Collider en la raíz o sus hijos.
            Debug.LogWarning("Este bolo necesita un Collider en el objeto raíz o en un hijo.", this); // Avisa si falta el Collider.
    }

    public void EsperarImpacto() // El controlador prepara el bolo al empezar cada lanzamiento.
    {
        cuerpo.isKinematic = true; // Conserva el bolo fijo hasta que la bola lo toque.
        cuerpo.useGravity = false; // Mantiene desactivada la gravedad antes del impacto.
        cuerpo.linearVelocity = Vector3.zero; // Elimina cualquier velocidad anterior.
        cuerpo.angularVelocity = Vector3.zero; // Elimina cualquier giro anterior.
        fisicaActivada = false; // Vuelve a bloquear el comportamiento de colisión del bolo.
        RecibioGolpe = false; // Borra el impacto anterior.
    }

    public void ActivarFisica() // El controlador llama aquí cuando la bola impacta por primera vez.
    {
        if (cuerpo == null) cuerpo = GetComponent<Rigidbody>(); // Recupera el Rigidbody por seguridad.
        cuerpo.isKinematic = false; // Permite que la física mueva el bolo.
        cuerpo.useGravity = true; // Activa la gravedad después del primer impacto real.
        cuerpo.WakeUp(); // Despierta el Rigidbody para que Unity lo simule.
        fisicaActivada = true; // Permite registrar choques entre bolos desde este momento.
    }

    public void RecibirImpactoDeBola(Vector3 posicionBola, Vector3 velocidadImpacto) // Aplica el golpe inicial al bolo tocado por la bola.
    {
        ActivarFisica(); // Asegura que el bolo ya pueda moverse y tenga gravedad.
        RecibioGolpe = true; // Registra que la bola ha tocado este bolo.

        Vector3 direccion = Vector3.ProjectOnPlane(cuerpo.position - posicionBola, Vector3.up); // Calcula la dirección horizontal desde la bola hasta el bolo.
        if (direccion.sqrMagnitude < 0.0001f) return; // Evita normalizar una dirección casi nula.
        direccion.Normalize(); // Convierte la dirección en un vector de longitud uno.

        float rapidez = Mathf.Clamp(velocidadImpacto.magnitude * 0.55f, 1.2f, 5f); // Ajusta la velocidad transferida para evitar un empujón desproporcionado.
        cuerpo.linearVelocity = direccion * rapidez; // Da al bolo una velocidad inicial en la dirección del golpe.

        Vector3 ejeDeGiro = Vector3.Cross(Vector3.up, direccion); // Calcula el eje alrededor del que debe inclinarse.
        if (ayudaDeGiro > 0f) // Aplica ayuda solo si está activada en el Inspector.
            cuerpo.AddTorque(ejeDeGiro * ayudaDeGiro, ForceMode.VelocityChange); // Añade un impulso de giro moderado.
    }

    public void Recolocar() // El controlador devuelve el bolo a su posición inicial al pulsar R.
    {
        if (cuerpo == null) cuerpo = GetComponent<Rigidbody>(); // Recupera el Rigidbody si aún no existe la referencia.
        if (!cuerpo.isKinematic) // Limpia velocidades si el Rigidbody estaba usando físicas.
        {
            cuerpo.linearVelocity = Vector3.zero; // Elimina el desplazamiento.
            cuerpo.angularVelocity = Vector3.zero; // Elimina el giro.
        }

        cuerpo.isKinematic = true; // Inmoviliza el bolo durante el reinicio.
        cuerpo.useGravity = false; // Desactiva la gravedad hasta el siguiente impacto.
        cuerpo.collisionDetectionMode = CollisionDetectionMode.Discrete; // Restaura la detección de colisiones normal.
        cuerpo.position = inicio; // Devuelve el bolo a la posición guardada.
        cuerpo.rotation = rotacionInicial; // Devuelve el bolo a su rotación guardada.
        fisicaActivada = false; // Vuelve a bloquear las colisiones de juego.
        RecibioGolpe = false; // Borra el estado del tiro anterior.
    }

    private void OnCollisionEnter(Collision choque) // Unity llama a este método cuando el bolo choca con algo.
    {
        if (!fisicaActivada || RecibioGolpe || choque.relativeVelocity.sqrMagnitude < 0.25f) return; // Ignora choques previos al impacto real o demasiado suaves.

        BoloBolera otroBolo = choque.collider.GetComponentInParent<BoloBolera>(); // Busca si el objeto que chocó es otro bolo.
        if (otroBolo == null) return; // Ignora el suelo, las paredes y otros elementos de la pista.

        RecibioGolpe = true; // Registra el choque entre bolos para que el tiro pueda terminar.
        Vector3 direccion = Vector3.ProjectOnPlane(cuerpo.position - otroBolo.cuerpo.position, Vector3.up); // Calcula la dirección horizontal del empujón.
        if (direccion.sqrMagnitude < 0.0001f) return; // Evita hacer cálculos con una dirección casi nula.
        Vector3 ejeDeGiro = Vector3.Cross(Vector3.up, direccion.normalized); // Calcula el eje para ayudar al vuelco.
        if (ayudaDeGiro > 0f) // Comprueba que la ayuda de giro no esté a cero.
            cuerpo.AddTorque(ejeDeGiro * ayudaDeGiro, ForceMode.VelocityChange); // Añade un pequeño giro por el choque con otro bolo.
    }
}
