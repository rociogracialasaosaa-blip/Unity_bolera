using UnityEngine; // Importa las clases básicas de Unity: Rigidbody, Vector3, tiempo, etc.
#if ENABLE_INPUT_SYSTEM // Comprueba si el proyecto tiene activado el nuevo sistema de entrada.
using UnityEngine.InputSystem; // Permite leer teclado y ratón con el nuevo Input System.
#endif // Termina la parte condicional del nuevo sistema de entrada.

[RequireComponent(typeof(Rigidbody))] // Asegura que el objeto Bola tenga un Rigidbody.
public class LanzamientoBolera : MonoBehaviour // Define el comportamiento del lanzamiento y la partida.
{ // Empieza la clase.
    [Header("Arrastra estos objetos desde la jerarquía")] // Muestra un título en el Inspector.
    [SerializeField] private Transform centroBolos; // Referencia al punto del centro de los bolos.
    [SerializeField] private Transform grupoBolos; // Referencia al padre que contiene todos los bolos.

    [Header("Ajusta el tiro al tamaño de tu pista")] // Agrupa los ajustes del tiro en el Inspector.
    [SerializeField, Min(0)] private float recorridoLateral = 1.5f; // Máximo desplazamiento lateral del apuntado, en unidades.
    [SerializeField, Min(0.2f)] private float segundosDeBarrido = 2.2f; // Duración de un barrido completo de la flecha.
    [SerializeField, Min(0.1f)] private float segundosDeCarga = 1.25f; // Tiempo necesario para cargar la potencia al máximo.
    [SerializeField, Min(0.1f)] private float velocidadMinima = 5f; // Velocidad de la bola cuando se lanza con poca carga.
    [SerializeField, Min(0.1f)] private float velocidadMaxima = 14f; // Velocidad máxima de lanzamiento.
    [SerializeField, Min(1f)] private float tiempoMaximoDeTiro = 10f; // Tiempo límite antes de cerrar el tiro.

    private Rigidbody bola; // Guarda el Rigidbody de la bola para moverla con física.
    private BoloBolera[] bolos; // Guarda todos los componentes de bolo que hay en el grupo.
    private Vector3 origen, avance; // Guarda el punto de salida y la dirección hacia los bolos.
    private float anguloMaximo, anguloActual, tiempoPunteria; // Guarda límites y estado del apuntado.
    private Quaternion rotacionInicial; // Guarda la rotación original de la bola para reiniciarla.
    private float tiempo, tiempoEnReposo; // Controlan el tiempo del tiro y la espera a que pare.
    private bool tiroPendiente; // Indica que el jugador ya soltó el ratón y toca lanzar.
    private bool bolosActivadosPorImpacto; // Evita activar las físicas antes del primer choque real con la bola.
    private int resultado; // Conserva el número final de bolos derribados.

    public enum Fase { Preparacion, Cargando, EnJuego, Resultado } // Nombra las cuatro fases posibles.
    public Fase Estado { get; private set; } // Permite consultar la fase, pero solo este script puede cambiarla.
    public float Potencia { get; private set; } // Expone la potencia para que el panel pueda mostrarla.
    public bool Listo { get; private set; } // Indica si las referencias y objetos están correctamente preparados.
    public int TotalBolos => bolos == null ? 0 : bolos.Length; // Devuelve cuántos bolos se han encontrado.
    public int Derribados => Estado == Fase.Resultado ? resultado : ContarBolos(); // Devuelve la puntuación actual o la final.

    public Vector3 OrigenTiro => origen; // Permite al panel conocer el punto donde comienza la bola.
    public Vector3 DireccionTiro => Quaternion.AngleAxis(anguloActual, Vector3.up) * avance; // Gira la dirección base según el ángulo elegido.
    public bool MostrarFlecha => Listo && (Estado == Fase.Preparacion || Estado == Fase.Cargando); // Muestra la flecha solo antes del lanzamiento.

    private void Start() // Unity llama a este método al comenzar la escena.
    { // Empieza la preparación.
        bola = GetComponent<Rigidbody>(); // Busca el Rigidbody del mismo objeto que tiene este script.
        if (centroBolos == null || grupoBolos == null) // Comprueba que se hayan conectado ambas referencias.
        { // Empieza el caso de referencias ausentes.
            Debug.LogError("Bolera: asigna Centro Bolos y Grupo Bolos en el Inspector.", this); // Avisa del error en la Consola.
            return; // Detiene la preparación para evitar errores posteriores.
        } // Termina la comprobación de referencias.

        bolos = grupoBolos.GetComponentsInChildren<BoloBolera>(); // Busca el script BoloBolera en el padre y sus hijos.
        if (bolos.Length == 0 || bola.GetComponentInChildren<Collider>() == null) // Comprueba que haya bolos y collider en la bola.
        { // Empieza el caso de escena incompleta.
            Debug.LogError("Bolera: necesitas una bola con Collider y al menos un BoloBolera activo.", this); // Explica qué componente falta.
            return; // No inicia el juego si faltan piezas.
        } // Termina la comprobación de objetos necesarios.

        origen = bola.position; // Guarda la posición inicial de la bola.
        rotacionInicial = bola.rotation; // Guarda la rotación inicial de la bola.
        // Calculamos el sentido con dos puntos de la escena. No importa hacia dónde gire la pista.
        avance = Vector3.ProjectOnPlane(centroBolos.position - origen, Vector3.up); // Calcula la dirección horizontal desde la bola al centro de los bolos.
        if (avance.sqrMagnitude < 0.0001f) // Comprueba que el centro de bolos no esté en la misma posición que la bola.
        { // Empieza la comprobación de distancia.
            Debug.LogError("Bolera: coloca Centro Bolos al fondo de la pista, separado de la bola.", this); // Avisa de que el punto está mal colocado.
            return; // Cancela la preparación.
        } // Termina la comprobación de distancia.
        // El arco se adapta a la distancia: el extremo apunta hasta Recorrido Lateral
        // unidades a un lado del centro de los bolos, sin mover la bola.
        anguloMaximo = Mathf.Atan2(recorridoLateral, avance.magnitude) * Mathf.Rad2Deg; // Convierte la anchura lateral permitida en un ángulo.
        avance.Normalize(); // Convierte la dirección en un vector de longitud uno.
        foreach (BoloBolera bolo in bolos) // Recorre cada bolo encontrado en el grupo.
            bolo.GuardarInicio(); // Pide a cada bolo que memorice su posición inicial.

        Listo = true; // Marca que la escena ya está preparada.
        Reiniciar(); // Coloca la bola y los bolos en su estado inicial.
    } // Termina Start.

    private void Update() // Se ejecuta una vez por cada fotograma y lee los controles.
    { // Empieza la lectura de controles.
        if (!Listo) return; // No hace nada hasta que la configuración sea válida.

#if ENABLE_INPUT_SYSTEM // Si está activo el nuevo Input System, usa sus controles.
        Keyboard teclado = Keyboard.current; // Obtiene el teclado conectado actualmente.
        Mouse raton = Mouse.current; // Obtiene el ratón conectado actualmente.
        bool reinicio = teclado != null && teclado.rKey.wasPressedThisFrame; // Detecta si se pulsó R en este fotograma.
        bool pulsar = raton != null && raton.leftButton.wasPressedThisFrame; // Detecta el inicio del clic izquierdo.
        bool soltar = raton != null && raton.leftButton.wasReleasedThisFrame; // Detecta cuándo se suelta el clic izquierdo.
#else // Si el nuevo sistema no está activo, usa el sistema clásico de Unity.
        bool reinicio = Input.GetKeyDown(KeyCode.R); // Detecta la tecla R para reiniciar.
        bool pulsar = Input.GetMouseButtonDown(0); // Detecta el clic izquierdo del ratón.
        bool soltar = Input.GetMouseButtonUp(0); // Detecta cuándo se suelta el clic izquierdo.
#endif // Termina la selección del sistema de entrada.

        if (reinicio) // Comprueba si el jugador quiere repetir la partida.
        { // Empieza el reinicio.
            Reiniciar(); // Devuelve la bola y los bolos a sus posiciones iniciales.
            return; // Termina Update para no procesar otro control a la vez.
        } // Termina el reinicio.

        if (Estado == Fase.EnJuego || Estado == Fase.Resultado || tiroPendiente) // Bloquea el control durante el tiro o el resultado.
            return; // Sale de Update hasta que se pueda volver a jugar.

        if (Estado == Fase.Preparacion) // Si aún no se está cargando, permite elegir dirección.
        { // Empieza el apuntado.
            // La flecha se mueve sola. Al pulsar, se queda en el ángulo elegido.
            if (pulsar) Estado = Fase.Cargando; // Al hacer clic, fija la dirección y comienza la carga.
            else // Si no se ha pulsado el ratón...
            { // Empieza el movimiento automático de la flecha.
                tiempoPunteria += Time.deltaTime; // Suma el tiempo transcurrido desde el fotograma anterior.
                float fase = tiempoPunteria * (2f * Mathf.PI / segundosDeBarrido); // Convierte el tiempo en una fase de movimiento periódico.
                anguloActual = Mathf.Sin(fase) * anguloMaximo; // Mueve el ángulo de izquierda a derecha suavemente.
                return; // Espera al siguiente fotograma sin cargar potencia.
            } // Termina el movimiento automático.
        } // Termina la fase de apuntado.

        Potencia = Mathf.Clamp01(Potencia + Time.deltaTime / segundosDeCarga); // Aumenta la potencia hasta un máximo de 1.
        if (soltar) tiroPendiente = true; // Al soltar el botón, deja preparado el lanzamiento.
    } // Termina Update.

    private void OnCollisionEnter(Collision choque) // Unity llama a este método cuando la bola choca con un objeto.
    { // Empieza la comprobación del impacto de la bola.
        if (!Listo || Estado != Fase.EnJuego || bolosActivadosPorImpacto) return; // Ignora choques fuera del tiro o si ya activó las físicas.
        if (choque.relativeVelocity.sqrMagnitude < 0.25f) return; // Ignora roces demasiado suaves.

        BoloBolera boloImpactado = choque.collider.GetComponentInParent<BoloBolera>(); // Comprueba si la bola ha chocado con un bolo.
        if (boloImpactado == null) return; // Ignora choques con la pista, paredes y decoración.

        bolosActivadosPorImpacto = true; // Marca que ya se produjo el primer impacto verdadero.
        foreach (BoloBolera bolo in bolos) // Recorre todos los bolos de la formación.
            bolo.ActivarFisica(); // Activa la gravedad de la formación solo después del impacto de la bola.

        boloImpactado.RecibirImpactoDeBola(bola.position, choque.relativeVelocity); // Da un impulso inicial controlado al bolo golpeado.
    } // Termina la comprobación del impacto de la bola.

    private void FixedUpdate() // Unity llama a este método en intervalos fijos para la física.
    { // Empieza la actualización de física.
        if (!Listo) return; // No ejecuta física si la escena no está preparada.
        if (Estado == Fase.Preparacion || Estado == Fase.Cargando) // Comprueba si estamos antes del lanzamiento.
        { // Empieza la espera de lanzamiento.
            if (!tiroPendiente) return; // Espera hasta que el jugador suelte el ratón.
            foreach (BoloBolera bolo in bolos) // Recorre todos los bolos.
                bolo.EsperarImpacto(); // Los mantiene quietos hasta que la bola llegue a la formación.

            bola.isKinematic = false; // Permite que la física mueva la bola.
            bola.useGravity = true; // Activa la gravedad de la bola.
            bola.constraints = RigidbodyConstraints.None; // Quita bloqueos de movimiento o giro.
            bola.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic; // Reduce la posibilidad de atravesar objetos a alta velocidad.
            // VelocityChange da la misma velocidad de salida aunque cambies la masa de la bola.
            float velocidad = Mathf.Lerp(velocidadMinima, Mathf.Max(velocidadMinima, velocidadMaxima), Potencia); // Calcula velocidad según la carga.
            bola.AddForce(DireccionTiro * velocidad, ForceMode.VelocityChange); // Lanza la bola hacia los bolos.
            Estado = Fase.EnJuego; // Cambia el estado a tiro en curso.
            tiroPendiente = false; // Consume la petición de lanzamiento.
            return; // Evita ejecutar también la lógica de final del tiro este mismo paso.
        } // Termina el bloque de lanzamiento.

        if (Estado != Fase.EnJuego) return; // Solo mide el tiro mientras la bola está en movimiento.
        tiempo += Time.fixedDeltaTime; // Suma el tiempo fijo de física.

        // Esperamos el choque o damos margen para que la bola llegue al final de la pista.
        bool puedeCerrar = false; // Indica si el tiro ya puede empezar a terminar.
        bool bolosQuietos = true; // Supone que los bolos están quietos hasta encontrar uno moviéndose.
        foreach (BoloBolera bolo in bolos) // Recorre cada bolo.
        { // Comprueba actividad de cada bolo.
            puedeCerrar |= bolo.RecibioGolpe || bolo.Derribado; // Recuerda si algún bolo recibió un choque o cayó.
            bolosQuietos &= bolo.EnReposo; // Solo sigue siendo verdadero si todos están en reposo.
        } // Termina el recorrido de bolos.
        puedeCerrar |= Vector3.Dot(bola.position - centroBolos.position, avance) > 0.5f // Comprueba si la bola ya pasó el centro de los bolos...
                      || (tiempo > 1f && bola.IsSleeping()); // ...o si se ha parado después de al menos un segundo.
        tiempoEnReposo = puedeCerrar && bolosQuietos ? tiempoEnReposo + Time.fixedDeltaTime : 0f; // Cuenta cuánto llevan quietos la bola y los bolos.

        if (tiempoEnReposo >= 0.6f || tiempo >= tiempoMaximoDeTiro) // Termina si todo está quieto o se alcanzó el límite.
        { // Empieza el cierre del tiro.
            resultado = ContarBolos(); // Guarda la puntuación final.
            Estado = Fase.Resultado; // Cambia la partida a la pantalla de resultado.
        } // Termina el cierre del tiro.
    } // Termina FixedUpdate.

    private int ContarBolos() // Cuenta los bolos que están derribados.
    { // Empieza el recuento.
        int cantidad = 0; // Empieza la cuenta desde cero.
        if (bolos == null || Estado == Fase.Preparacion || Estado == Fase.Cargando) // Evita contar antes de que empiece el tiro.
            return 0; // En preparación, la puntuación es cero.
        foreach (BoloBolera bolo in bolos) // Revisa uno por uno los bolos.
            if (bolo.Derribado) cantidad++; // Suma uno si este bolo está caído.
        return cantidad; // Devuelve el total derribado.
    } // Termina el recuento.

    private void Reiniciar() // Devuelve la partida a su estado inicial.
    { // Empieza el reinicio.
        // Recuperamos las posiciones iniciales sin recargar la escena.
        if (!bola.isKinematic) // Solo limpia velocidades si la bola estaba usando física.
        { // Empieza la limpieza del movimiento.
            bola.linearVelocity = Vector3.zero; // Quita la velocidad de desplazamiento.
            bola.angularVelocity = Vector3.zero; // Quita la velocidad de giro.
        } // Termina la limpieza del movimiento.
        bola.collisionDetectionMode = CollisionDetectionMode.Discrete; // Restaura la detección normal de colisiones.
        bola.isKinematic = true; // Deja la bola quieta hasta el próximo lanzamiento.
        bola.position = origen; // Devuelve la bola a su posición guardada.
        bola.rotation = rotacionInicial; // Devuelve la bola a su rotación guardada.
        foreach (BoloBolera bolo in bolos) // Recorre cada bolo.
            bolo.Recolocar(); // Devuelve ese bolo a su sitio y lo deja en reposo.

        anguloActual = tiempoPunteria = Potencia = tiempo = tiempoEnReposo = 0f; // Reinicia todos los contadores y valores del tiro.
        resultado = 0; // Borra la puntuación anterior.
        tiroPendiente = false; // Cancela cualquier lanzamiento pendiente.
        bolosActivadosPorImpacto = false; // Permite detectar el primer impacto del siguiente tiro.
        Estado = Fase.Preparacion; // Vuelve a la fase inicial.
    } // Termina Reiniciar.
} // Termina la clase.
