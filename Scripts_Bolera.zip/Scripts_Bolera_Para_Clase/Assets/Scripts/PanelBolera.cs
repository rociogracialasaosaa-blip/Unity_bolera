using UnityEngine; // Importa las herramientas de Unity para cámara, interfaz y dibujo.

// Este script solo presenta la información; no mueve la bola ni calcula las colisiones.
[RequireComponent(typeof(LanzamientoBolera))] // Exige que el objeto tenga el script que controla el lanzamiento.
public class PanelBolera : MonoBehaviour // Define el panel de potencia, instrucciones, puntuación y flecha.
{ // Comienza la clase.
    private LanzamientoBolera partida; // Referencia al controlador de la partida.
    private Camera camara; // Referencia a la cámara principal para proyectar la flecha.
    private GUIStyle marcador, detalle; // Estilos de los dos tamaños de texto.

    private void Awake() // Unity ejecuta Awake al cargar este objeto.
    { // Comienza la preparación de referencias.
        partida = GetComponent<LanzamientoBolera>(); // Busca el script de lanzamiento en el mismo objeto.
        camara = Camera.main; // Busca la cámara marcada con el tag MainCamera.
    } // Termina Awake.

    private void OnGUI() // Unity llama a OnGUI para dibujar la interfaz.
    { // Comienza el dibujo.
        if (Event.current.type != EventType.Repaint || partida == null) return; // Solo dibuja en el repintado y si existe el controlador.
        if (partida.MostrarFlecha && camara != null) DibujarFlecha(); // Dibuja la flecha antes del lanzamiento si hay cámara.
        if (marcador == null) // Comprueba si aún hay que preparar los estilos de texto.
        { // Comienza la preparación de estilos.
            marcador = new GUIStyle(GUI.skin.label) { fontSize = 15, fontStyle = FontStyle.Bold }; // Crea el estilo grande y en negrita.
            marcador.normal.textColor = Color.white; // Pone el marcador en blanco.
            detalle = new GUIStyle(GUI.skin.label) { fontSize = 12 }; // Crea el estilo pequeño para instrucciones.
            detalle.normal.textColor = new Color(.88f, .94f, 1f); // Pone las instrucciones en un tono azul claro.
        } // Termina la preparación de estilos.

        // El panel tiene tamaño máximo de 320 × 47 y se coloca abajo para no tapar los bolos.
        float escala = Mathf.Min(1f, Mathf.Max(1f, Screen.width - 16f) / 320f, // Ajusta el panel a pantallas estrechas...
                                     Mathf.Max(1f, Screen.height - 16f) / 47f); // ...y también a pantallas bajas.
        float x = (Screen.width - 320f * escala) * .5f; // Calcula su posición horizontal centrada.
        float y = Screen.height - 8f - 47f * escala; // Lo sitúa cerca de la parte inferior de la pantalla.
        Matrix4x4 anterior = GUI.matrix; // Guarda la transformación actual antes de mover el panel.
        GUI.matrix = Matrix4x4.TRS(new Vector3(x, y, 0), Quaternion.identity, // Prepara la posición del panel...
                                   new Vector3(escala, escala, 1f)) * anterior; // ...y aplica el tamaño calculado.
        Pintar(new Rect(0, 0, 320, 47), new Color(.05f, .08f, .14f, .92f)); // Dibuja el fondo oscuro semitransparente.

        if (!partida.Listo) // Comprueba si el controlador encontró una configuración incompleta.
        { // Comienza el mensaje de error de configuración.
            GUI.Label(new Rect(9, 1, 302, 24), "Bolera sin configurar", marcador); // Muestra un aviso destacado.
            GUI.Label(new Rect(9, 25, 302, 18), "Revisa el Inspector y la consola.", detalle); // Indica dónde buscar el fallo.
            GUI.matrix = anterior; // Restaura la transformación de pantalla.
            return; // Sale para no dibujar la información normal.
        } // Termina el mensaje de configuración.

        GUI.Label(new Rect(9, 1, 145, 24), $"Bolos: {partida.Derribados}/{partida.TotalBolos}", marcador); // Muestra derribados y total.
        bool terminado = partida.Estado == LanzamientoBolera.Fase.Resultado; // Comprueba si el tiro ha terminado.
        if (!terminado) // Mientras la partida aún no está en el resultado...
        { // Comienza el dibujo de potencia.
            int porcentaje = Mathf.RoundToInt(partida.Potencia * 100f); // Convierte la potencia de 0–1 a un porcentaje entero.
            GUI.Label(new Rect(154, 2, 105, 22), $"Potencia {porcentaje} %", detalle); // Escribe el porcentaje en el panel.
            Pintar(new Rect(257, 10, 53, 6), new Color(.28f, .34f, .43f)); // Dibuja la base gris de la barra.
            if (partida.Potencia > 0) // Si la potencia ya es mayor que cero...
                Pintar(new Rect(257, 10, 53 * partida.Potencia, 6), new Color(.25f, .88f, .69f)); // ...dibuja el relleno verde proporcional.
        } // Termina la barra de potencia.
        else // Si el tiro ha terminado...
        { // Comienza el mensaje de resultado.
            bool pleno = partida.Derribados == partida.TotalBolos; // Comprueba si cayeron todos los bolos.
            GUI.Label(new Rect(154, 2, 155, 22), pleno ? "¡Pleno!" : "Tiro terminado", marcador); // Escribe el resultado adecuado.
        } // Termina el mensaje de resultado.

        string mensaje; // Reserva espacio para el texto de instrucciones.
        switch (partida.Estado) // Elige qué instrucción corresponde a la fase actual.
        { // Comienza la selección.
            case LanzamientoBolera.Fase.Cargando: mensaje = "Suelta el ratón para lanzar"; break; // Durante la carga, indica que hay que soltar.
            case LanzamientoBolera.Fase.EnJuego: mensaje = "Tiro en curso  •  R para repetir"; break; // Durante el movimiento, informa de que el tiro sigue activo.
            case LanzamientoBolera.Fase.Resultado: mensaje = "Pulsa R para repetir"; break; // En el resultado, indica cómo repetir.
            default: mensaje = "Mantén clic izquierdo para apuntar y cargar"; break; // En preparación, explica el control inicial.
        } // Termina la selección.
        GUI.Label(new Rect(9, 25, 302, 18), mensaje, detalle); // Dibuja el mensaje elegido.
        GUI.matrix = anterior; // Devuelve la interfaz a su transformación original.
    } // Termina OnGUI.

    private void DibujarFlecha() // Calcula y dibuja el indicador de dirección.
    { // Comienza el cálculo de la flecha.
        Vector3 direccion = partida.DireccionTiro; // Lee la dirección de lanzamiento actual.
        Vector3 origen = partida.OrigenTiro + Vector3.up * .08f; // Eleva ligeramente la flecha sobre la pista.
        Vector3 a = camara.WorldToScreenPoint(origen + direccion * .48f); // Convierte el inicio de la flecha a coordenadas de pantalla.
        Vector3 b = camara.WorldToScreenPoint(origen + direccion * 4.1f); // Convierte su punta a coordenadas de pantalla.
        if (a.z <= 0 || b.z <= 0) return; // No la dibuja si queda detrás de la cámara.

        Vector2 inicio = new Vector2(a.x, Screen.height - a.y); // Ajusta la coordenada vertical al origen de GUI.
        Vector2 punta = new Vector2(b.x, Screen.height - b.y); // Hace el mismo ajuste para la punta.
        if ((punta - inicio).sqrMagnitude < 36f) return; // Evita dibujar una flecha demasiado pequeña.
        Vector2 eje = (punta - inicio).normalized; // Calcula la dirección normalizada de la flecha.
        Vector2 lado = new Vector2(-eje.y, eje.x); // Calcula una dirección perpendicular para las alas.
        float tam = Mathf.Clamp((punta - inicio).magnitude * .16f, 6f, 14f); // Ajusta la punta al largo, con mínimo y máximo.
        Vector2 izq = punta - eje * tam + lado * tam * .63f; // Calcula el extremo izquierdo de la punta.
        Vector2 der = punta - eje * tam - lado * tam * .63f; // Calcula el extremo derecho de la punta.

        // Primero dibuja una sombra y encima el trazo de color para que contraste con la pista.
        Color sombra = new Color(.04f, .08f, .13f, .9f); // Define el color oscuro de la sombra.
        Color color = partida.Estado == LanzamientoBolera.Fase.Cargando // Comprueba si se está cargando el lanzamiento...
            ? new Color(.28f, 1f, .77f) : new Color(1f, .91f, .53f); // ...y elige verde al cargar o amarillo al apuntar.
        Segmento(inicio, punta, 7f, sombra); // Dibuja sombra bajo el cuerpo de la flecha.
        Segmento(izq, punta, 7f, sombra); // Dibuja sombra bajo el ala izquierda.
        Segmento(der, punta, 7f, sombra); // Dibuja sombra bajo el ala derecha.
        Segmento(inicio, punta, 3f, color); // Dibuja el cuerpo coloreado encima de la sombra.
        Segmento(izq, punta, 3f, color); // Dibuja el ala izquierda coloreada.
        Segmento(der, punta, 3f, color); // Dibuja el ala derecha coloreada.
    } // Termina DibujarFlecha.

    private static void Segmento(Vector2 a, Vector2 b, float ancho, Color color) // Dibuja una línea como rectángulo girado.
    { // Comienza Segmento.
        Matrix4x4 anterior = GUI.matrix; // Guarda la transformación actual de la interfaz.
        Vector2 delta = b - a; // Calcula la distancia y la dirección entre puntos.
        GUIUtility.RotateAroundPivot(Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg, a); // Gira alrededor del inicio para alinear el trazo.
        Pintar(new Rect(a.x, a.y - ancho / 2f, delta.magnitude, ancho), color); // Dibuja el rectángulo que forma la línea.
        GUI.matrix = anterior; // Restaura la transformación original.
    } // Termina Segmento.

    private static void Pintar(Rect rect, Color color) // Dibuja un rectángulo coloreado.
    { // Comienza Pintar.
        Color anterior = GUI.color; // Guarda el color de GUI existente.
        GUI.color = color; // Establece el color solicitado.
        GUI.DrawTexture(rect, Texture2D.whiteTexture); // Dibuja la textura blanca teñida de ese color.
        GUI.color = anterior; // Restaura el color anterior para otros elementos.
    } // Termina Pintar.
} // Termina la clase.
